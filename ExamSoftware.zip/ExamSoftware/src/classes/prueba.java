/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package classes;
//
///**
// *
// * @author Green
// */
//public class prueba {
//    "<html> enunciado cuyalsendfibsdagibadiogb <br> <img src='/resources/cap1pregunta6.png'> </html>"
//}
